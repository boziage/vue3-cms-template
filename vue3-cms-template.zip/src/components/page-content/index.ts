import PageContent from './src/page-content.vue'

export default PageContent
