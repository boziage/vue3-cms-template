import SvgIcon from './src/svg-icon.vue'

export default SvgIcon
