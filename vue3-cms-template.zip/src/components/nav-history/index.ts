import NavHistory from './src/nav-history.vue'

export default NavHistory
