<template>
  <div class="nav-menu">
    <div class="logo">
      <img class="img" src="~@/assets/img/logo.svg" alt="logo" />
      <span v-if="!collapse" class="title">Vue3+TS</span>
    </div>
    <el-menu
      :default-active="defaultValue"
      class="el-menu-vertical"
      :collapse="collapse"
      background-color="#0c2135"
      text-color="#b7bdc3"
      active-text-color="#0a60bd"
    >
      <template v-for="item in userMenus" :key="item.id">
        <template v-if="item.type === 1">
          <el-sub-menu :index="item.id + ''">
            <template #title>
              <el-icon v-if="item.icon">
                <component :is="item.icon" />
              </el-icon>
              <span>{{ $t(`menus.${item.name}`) }}</span>
            </template>
            <template v-for="subitem in item.children" :key="subitem.id">
              <el-menu-item
                :index="subitem.id + ''"
                @click="handleMenuItemClick(subitem)"
              >
                <el-icon v-if="subitem.icon">
                  <component :is="subitem.icon" />
                </el-icon>
                <span>{{ $t(`menus.${subitem.name}`) }}</span>
              </el-menu-item>
            </template>
          </el-sub-menu>
        </template>
        <template v-else-if="item.type === 2">
          <el-menu-item :index="item.id + ''">
            <el-icon v-if="item.icon">
              <component :is="item.icon" />
            </el-icon>
            <span>{{ $t(`menus.${item.name}`) }}</span>
          </el-menu-item>
        </template>
      </template>
    </el-menu>
  </div>
</template>

<script lang="ts" setup>
import { ref, watchEffect, defineProps, withDefaults, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'

import localCache from '@/utils/cache'

import { mapPathToMenus } from '@/hooks/map-menus'

import { useStore } from '@/store'

let currentPath: any
let menu: any

withDefaults(
  defineProps<{
    collapse: boolean
  }>(),
  {
    collapse: false
  }
)

const route = useRoute()
const router = useRouter()
const store = useStore()

const defaultValue = ref('')

const userMenus = computed(() => {
  return store.state.login.userMenus
})

watchEffect(() => {
  if (localCache.getCache('token')) {
    currentPath = route.path
    menu = mapPathToMenus(userMenus.value, currentPath)
    if (menu) defaultValue.value = menu.id + ''
  }
})

const handleMenuItemClick = (item: any) => {
  router.push({
    path: item.url ?? '/not-found'
  })
}
</script>

<style lang="scss" scoped>
.nav-menu {
  height: 100%;
  background-color: #001529;
  cursor: auto;

  .logo {
    display: flex;
    height: 24px;
    padding: 12px 0px 12px 10px;
    box-sizing: content-box;
    justify-content: flex-start;
    align-items: center;
    .img {
      height: 100%;
      margin: 0 10px;
    }
    .title {
      font-size: 20px;
      font-weight: 700;
      color: white;
    }
  }

  .el-menu {
    border-right: none;
  }

  // 目录
  .el-sub-menu {
    background-color: #001529 !important;
    // 二级菜单 ( 默认背景 )
    .el-menu-item {
      padding-left: 49px !important;
      background-color: #0c2135 !important;
    }
  }

  :deep(.el-submenu__title) {
    background-color: #001529 !important;
    color: white;
  }

  // hover 高亮
  .el-menu-item:hover {
    color: #fff !important; // 菜单
  }

  .el-menu-item.is-active {
    color: #fff !important;
    background-color: #0a60bd !important;
  }
}

.el-menu-vertical:not(.el-menu--collapse) {
  width: 100%;
  height: calc(100% - 48px);
}
</style>
