import BoForm from './src/form.vue'

export * from './types'

export default BoForm
