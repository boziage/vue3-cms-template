import BoBreadcrumb from './src/breadcrumb.vue'

export * from './types'

export default BoBreadcrumb
