import BoCountUp from './src/count-up.vue'

export default BoCountUp
