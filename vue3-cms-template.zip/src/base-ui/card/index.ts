import BoCard from './src/card.vue'

export default BoCard
