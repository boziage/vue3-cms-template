import BoTextLink from './src/text-link.vue'

export default BoTextLink
