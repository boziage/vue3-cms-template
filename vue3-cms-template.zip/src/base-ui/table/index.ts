import BoTable from './src/table.vue'

export default BoTable
