export interface IDataType<T = any> {
  data: T
  meta: T
}
