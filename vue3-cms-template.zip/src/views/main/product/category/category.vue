<template>
  <div class="category">
    <h2>category</h2>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'category',
  setup() {
    return {}
  }
})
</script>

<style scoped></style>
