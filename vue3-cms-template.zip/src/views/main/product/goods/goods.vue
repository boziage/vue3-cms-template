<template>
  <div class="goods">
    <h2>goods</h2>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'goods',
  setup() {
    return {}
  }
})
</script>

<style scoped></style>
