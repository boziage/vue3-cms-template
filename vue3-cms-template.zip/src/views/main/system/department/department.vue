<template>
  <div class="department">
    <h2>department</h2>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'department',
  setup() {
    return {}
  }
})
</script>

<style scoped></style>
