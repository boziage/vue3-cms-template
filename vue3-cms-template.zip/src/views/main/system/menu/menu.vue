<template>
  <div class="menu">
    <h2>menu</h2>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'bo-menu',
  setup() {
    return {}
  }
})
</script>

<style scoped></style>
