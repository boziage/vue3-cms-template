<template>
  <div class="role">
    <h2>role</h2>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'role',
  setup() {
    return {}
  }
})
</script>

<style scoped></style>
