<template>
  <div class="dashboard">
    <h2>dashboard</h2>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'dashboard',
  setup() {
    return {}
  }
})
</script>

<style scoped></style>
