<template>
  <div class="list">
    <h2>list</h2>
  </div>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'list',
  setup() {
    return {}
  }
})
</script>

<style scoped></style>
