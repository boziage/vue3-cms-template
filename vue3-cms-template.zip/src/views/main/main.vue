<template>
  <div class="main">
    <layout />
  </div>
</template>

<style lang="scss" scoped>
.main {
  width: 100%;
  height: 100%;
}
</style>
